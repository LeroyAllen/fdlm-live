// ============================================================================
//  FDLM Live — config for YOUR OWN backend.
//  Fill in the values below and this app talks to YOUR Supabase (not Leroy's).
//  These are NOT secret (anon key + VAPID public key are public by design).
//  Empty values → the app shows "Supabase config missing" until you fill them in
//  (which also means it is NOT touching anyone else's backend).
//  Full walkthrough: handoff-amos/README-AMOS.md
// ============================================================================
window.__SB_URL = "";        // Supabase → Project Settings → API → Project URL
window.__SB_ANON = "";       // Supabase → Project Settings → API → anon / public key
window.__VAPID_PUBLIC = "";  // your VAPID PUBLIC key (README step 3–4)
window.__GMAPS_KEY = "";     // optional Google Maps key; leave empty for the free CARTO map
