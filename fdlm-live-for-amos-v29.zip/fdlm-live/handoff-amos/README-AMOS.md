# FDLM Live — run your own copy (Supabase) 🗺️

Hi Amos — this is the full live‑map app. The **frontend** (the `index.html`,
`app.js`, `sw.js`, icons…) is just static files that run anywhere. The only
thing tied to Leroy is the **backend** (his Supabase). This guide gets you your
own, independent backend in ~20 minutes — your own data, your own crew, your own
URL. No Firebase, no build step.

> **Fastest path:** if you use Claude/Cowork, just drop this whole folder in and
> say *"set up my own Supabase backend for this app following handoff-amos/README-AMOS.md"*.
> It can do steps 1–6 for you via the Supabase tools. Otherwise, do it by hand below.

**Good to know:** this folder contains **no secrets**. The Supabase anon key and
the VAPID *public* key are public by design. The only real secret — the VAPID
*private* key — lives inside your Supabase database, never in these files.

---

## What you'll set up
1. A free Supabase project (the database + realtime)
2. The tables (one SQL paste)
3. Web‑Push keys (so chat notifications work)
4. The `send-push` function (sends the notifications)
5. Your `config.js` (points the app at *your* backend)
6. Hosting (a public HTTPS URL) + install on your iPhone

---

## 1) Create a Supabase project
1. Go to **https://supabase.com** → sign in → **New project**.
2. Name it (e.g. `fdlm-live-amos`), pick a region near you (e.g. `eu-west-1` /
   Frankfurt), set a DB password (save it), **Free plan**. Create.
3. Wait ~2 min until it's ready.

## 2) Create the tables
1. Left sidebar → **SQL Editor** → **New query**.
2. Open **`handoff-amos/schema.sql`** (in this folder), copy **everything**,
   paste it in, click **Run**. You should see "Success". *(Safe to re‑run.)*

This creates all 6 tables (members, events, messages, push_subscriptions,
app_secrets, meet_pins), the security rules, and turns on realtime.

## 3) Generate your Web‑Push (VAPID) keys
You need your **own** pair (you can't reuse Leroy's — his private key stays with
him). Easiest:

- On a computer with Node: run
  ```
  npx web-push generate-vapid-keys
  ```
  It prints a **Public Key** and a **Private Key**.
- No Node? Use an online generator like **https://vapidkeys.com** (it runs in your
  browser). Copy both keys.

Keep both handy for the next steps. The **private** key is secret.

## 4) Store the private key in your database
1. Supabase → **SQL Editor** → **New query**, paste this (swap in your private
   key), Run:
   ```sql
   insert into public.app_secrets (key, value)
   values ('vapid_private', 'PASTE_YOUR_VAPID_PRIVATE_KEY')
   on conflict (key) do update set value = excluded.value;
   ```
   This row can't be read by the app — only by the function in step 5.

## 5) Deploy the `send-push` function
The code is already in this folder at **`supabase/functions/send-push/index.ts`**.
First edit two lines near the top:
- `VAPID_PUBLIC = "..."` → your **public** key from step 3
- `VAPID_SUBJECT = "mailto:..."` → your email

Then deploy it (pick one):
- **Dashboard (no install):** Supabase → **Edge Functions** → **Deploy a function**
  → name it exactly `send-push` → paste the edited `index.ts` → Deploy. Leave
  "Verify JWT" **on** (default).
- **CLI:** install the Supabase CLI, then from this folder:
  ```
  supabase login
  supabase functions deploy send-push --project-ref YOUR-PROJECT-REF
  ```
  (`YOUR-PROJECT-REF` is the bit in your project URL `https://<ref>.supabase.co`.)

*The function automatically gets the database access it needs — no extra env to set.*

## 6) Point the app at your backend (`config.js`)
1. Supabase → **Project Settings** → **API**: copy your **Project URL** and your
   **anon / public** key.
2. Open **`config.js`** in the app folder — it ships **blank with comments**.
   Fill in the 4 values: your Project URL, your anon key, your VAPID **public**
   key, and leave the Maps key empty (free CARTO map). Save.
   *(Until you fill it in, the app just shows "Supabase config missing" — that's
   expected, and it means the app is NOT touching anyone else's backend.)*
   *(`handoff-amos/config.template.js` is the same thing with extra notes.)*

## 7) Put it online
The app must be served over **HTTPS** (GPS + push require it). Easiest:
- **Netlify Drop:** go to **https://app.netlify.com/drop** and drag the **app
  folder** (the one containing `index.html`) onto the page. You get an instant
  HTTPS link. *(You can skip uploading the `handoff-amos/` folder and any `.git`.)*
- **or GitHub Pages:** create a repo, upload the files, Settings → Pages →
  deploy from `main`.

## 8) Install + test on your iPhone
1. Open your new URL in **Safari** → Share → **Add to Home Screen**.
2. Open it from the new icon → enter your name → **allow Location**.
3. When the "🔔 Get a ping…" banner appears, tap **Enable** → allow notifications.
4. From a second phone/browser (your new URL), send a crew chat message → the
   first phone should get a push titled **"💬 Crew Chat"**, and you should see
   both pins on the map.

That's it — you're fully independent. 🎉

---

## Notes & troubleshooting
- **The line‑ups / venues** (incl. your sets) are hardcoded in `app.js` in the
  `VENUES` list near the top — edit names/times there if your event differs.
- **Map is grey / no streets?** That's fine — with an empty Maps key the app uses
  the free CARTO map. Add your own Google Maps key in `config.js` only if you want
  Google's base map (and restrict it to your domain).
- **No push on iPhone?** Push only works after **Add to Home Screen** (iOS 16.4+),
  not in a normal Safari tab. Re‑check steps 3–5 (public key must match in both
  `config.js` and the function; private key must be in `app_secrets`).
- **"violates row‑level security" on push_subscriptions** is expected if you try
  to *read* that table as the app — only the function reads it. Not a problem.
- **Keep `app_secrets` with no policies.** That's what keeps your private key
  unreadable from the browser.
