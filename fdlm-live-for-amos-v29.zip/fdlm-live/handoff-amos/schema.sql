-- ============================================================================
--  FDLM Live V2 — Supabase schema (independent instance)
--  Mirrors the live production DB 1:1: members, events, messages,
--  push_subscriptions, app_secrets, meet_pins — incl. RLS + Realtime.
--
--  HOW TO RUN: open your NEW Supabase project → SQL Editor → New query →
--  paste this whole file → Run. Safe to run more than once (idempotent).
-- ============================================================================

-- 1) TABLES ------------------------------------------------------------------
create table if not exists public.members (
  id          text primary key,
  name        text not null check (char_length(name) between 1 and 30),
  photo       text check (photo is null or char_length(photo) < 80000),  -- small base64 avatar
  lat         double precision,
  lng         double precision,
  hidden      boolean not null default false,
  status      text check (status is null or status in ('here','otw','bar','home')),
  updated_at  timestamptz not null default now()
);

create table if not exists public.events (
  id          uuid primary key default gen_random_uuid(),
  name        text not null check (char_length(name) between 1 and 80),
  address     text,
  lat         double precision,
  lng         double precision,
  date_label  text,
  start_ts    timestamptz,
  end_ts      timestamptz,
  lineup      jsonb not null default '[]'::jsonb,
  color       text,
  emoji       text,
  added_by    text,
  created_at  timestamptz not null default now()
);

create table if not exists public.messages (
  id          bigint generated always as identity primary key,
  channel     text not null check (char_length(channel) between 1 and 100),
  uid         text not null,
  name        text,
  text        text not null check (char_length(text) between 1 and 280),
  created_at  timestamptz not null default now()
);
create index if not exists messages_channel_created_idx on public.messages (channel, created_at);

-- server-only (no SELECT policy below → the anon client can write its own row
-- but cannot read anyone's; only the send-push function reads it via service role)
create table if not exists public.push_subscriptions (
  uid          text primary key,
  subscription jsonb not null,
  created_at   timestamptz not null default now()
);

-- server-only (RLS on + ZERO policies → unreadable by anon; holds vapid_private)
create table if not exists public.app_secrets (
  key   text primary key,
  value text not null
);

create table if not exists public.meet_pins (
  id              uuid primary key default gen_random_uuid(),
  lat             double precision not null,
  lng             double precision not null,
  label           text not null default 'Meet here',
  created_by      text,
  created_by_name text,
  created_at      timestamptz not null default now(),
  expires_at      timestamptz not null
);

-- 2) ROW LEVEL SECURITY ------------------------------------------------------
alter table public.members            enable row level security;
alter table public.events             enable row level security;
alter table public.messages           enable row level security;
alter table public.push_subscriptions enable row level security;
alter table public.app_secrets        enable row level security;
alter table public.meet_pins          enable row level security;

-- This app has NO login: every client is the `anon` role, and uid/name are
-- client-supplied. Policies are intentionally permissive (true) — fine for a
-- small, trusted, ephemeral festival crew. app_secrets gets NO policy on purpose.

drop policy if exists members_select on public.members;
drop policy if exists members_insert on public.members;
drop policy if exists members_update on public.members;
drop policy if exists members_delete on public.members;
create policy members_select on public.members for select to anon using (true);
create policy members_insert on public.members for insert to anon with check (true);
create policy members_update on public.members for update to anon using (true) with check (true);
create policy members_delete on public.members for delete to anon using (true);

drop policy if exists events_select on public.events;
drop policy if exists events_insert on public.events;
drop policy if exists events_delete on public.events;
create policy events_select on public.events for select to anon using (true);
create policy events_insert on public.events for insert to anon with check (true);
create policy events_delete on public.events for delete to anon using (true);

drop policy if exists messages_select on public.messages;
drop policy if exists messages_insert on public.messages;
create policy messages_select on public.messages for select to anon using (true);
create policy messages_insert on public.messages for insert to anon with check (true);

drop policy if exists meet_pins_read   on public.meet_pins;
drop policy if exists meet_pins_insert on public.meet_pins;
drop policy if exists meet_pins_delete on public.meet_pins;
create policy meet_pins_read   on public.meet_pins for select using (true);
create policy meet_pins_insert on public.meet_pins for insert with check (true);
create policy meet_pins_delete on public.meet_pins for delete using (true);

drop policy if exists push_insert on public.push_subscriptions;
drop policy if exists push_update on public.push_subscriptions;
create policy push_insert on public.push_subscriptions for insert to anon with check (true);
create policy push_update on public.push_subscriptions for update to anon using (true) with check (true);

-- app_secrets: leave with ZERO policies. Do NOT add one.

-- 3) REALTIME (members, events, messages, meet_pins) -------------------------
do $$
declare t text;
begin
  foreach t in array array['members','events','messages','meet_pins'] loop
    if not exists (
      select 1 from pg_publication_tables
      where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = t
    ) then
      execute format('alter publication supabase_realtime add table public.%I', t);
    end if;
  end loop;
end $$;

-- 4) SECRET: store your VAPID private key (see README step 4). Example:
--    insert into public.app_secrets (key, value)
--    values ('vapid_private', 'PASTE_YOUR_VAPID_PRIVATE_KEY')
--    on conflict (key) do update set value = excluded.value;

-- Done. ✅
