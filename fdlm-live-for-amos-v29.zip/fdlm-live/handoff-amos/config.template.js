// ============================================================================
//  FDLM Live V2 — public client config (Amos's own instance)
//  These values are NOT secret (the Supabase anon key + VAPID public key are
//  public by design, protected by RLS / push signature). The SECRET VAPID
//  private key lives ONLY in your Supabase table app_secrets — never here.
//
//  → Fill in the 4 values below, then SAVE this file as `config.js` in the app
//    folder (replacing the existing config.js that points at Leroy's backend).
// ============================================================================

// 1) Supabase → Project Settings → Data API → Project URL
window.__SB_URL = "https://YOUR-PROJECT-REF.supabase.co";

// 2) Supabase → Project Settings → API Keys → anon / public key (the long JWT)
window.__SB_ANON = "PASTE_YOUR_SUPABASE_ANON_KEY";

// 3) Your VAPID PUBLIC key (see README step 4 — same one you also put in the
//    send-push edge function). The matching PRIVATE key goes in app_secrets only.
window.__VAPID_PUBLIC = "PASTE_YOUR_VAPID_PUBLIC_KEY";

// 4) Google Maps key — OPTIONAL. Leave it EMPTY to use the free CARTO map (no
//    key, no billing, works everywhere). Only set this if you want Google's
//    base map: create a key in Google Cloud (enable "Maps JavaScript API" +
//    billing), then restrict it to your own domain.
window.__GMAPS_KEY = "";
